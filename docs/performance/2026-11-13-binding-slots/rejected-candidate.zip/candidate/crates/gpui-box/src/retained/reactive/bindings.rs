//! Reusable storage slots. Public identity remains the full monotonic BindingId.
use super::*;

#[derive(Default)]
pub(super) struct Bindings {
    indices: HashMap<BindingId, usize>,
    slots: Vec<Option<(BindingId, Binding)>>,
    free: Vec<usize>,
}
impl Bindings {
    pub fn len(&self) -> usize { self.indices.len() }
    pub fn contains_key(&self, id: &BindingId) -> bool { self.indices.contains_key(id) }
    pub fn insert(&mut self, id: BindingId, binding: Binding) -> usize {
        assert!(!self.indices.contains_key(&id), "fresh binding identity");
        let index = self.free.pop().unwrap_or(self.slots.len());
        if index == self.slots.len() { self.slots.push(None); }
        self.slots[index] = Some((id, binding));
        self.indices.insert(id, index);
        index
    }
    pub fn at(&self, id: BindingId, slot: usize) -> &Binding {
        let (actual, binding) = self.slots[slot].as_ref().expect("live source binding");
        assert_eq!(*actual, id, "exact source binding identity");
        binding
    }
    #[cfg(test)]
    pub fn get_mut(&mut self, id: &BindingId) -> Option<&mut Binding> {
        let index = *self.indices.get(id)?;
        self.slots[index].as_mut().map(|(_, binding)| binding)
    }
    pub fn remove(&mut self, id: &BindingId) -> Option<Binding> {
        let index = self.indices.remove(id)?;
        let (actual, binding) = self.slots[index].take().expect("indexed binding");
        assert_eq!(actual, *id);
        self.free.push(index);
        Some(binding)
    }
    pub fn iter(&self) -> impl Iterator<Item = (&BindingId, &Binding)> {
        self.slots.iter().filter_map(|s| s.as_ref().map(|(id, binding)| (id, binding)))
    }
}
impl std::ops::Index<&BindingId> for Bindings {
    type Output = Binding;
    fn index(&self, id: &BindingId) -> &Binding {
        self.at(*id, self.indices[id])
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn reusable_slots_preserve_identity_and_source_order_through_churn() {
        let tree = UiTree::new(Style::default(), 0).unwrap();
        let mut ui = ReactiveUi::new(tree, BackendCapabilities::default()).unwrap();
        let signal = ui.signal(0u32);
        let nodes = (0..33).map(|_| ui.append(ui.root(), Style::default(), 0).unwrap()).collect::<Vec<_>>();
        let mut retired = vec![];
        for round in 0..8 {
            let mut ids = vec![];
            let log = Rc::new(std::cell::RefCell::new(Vec::new()));
            for &node in nodes.iter().rev() {
                let (id, _) = ui.bind(signal, Property::color(node)).unwrap();
                let original = std::mem::replace(&mut ui.bindings.get_mut(&id).unwrap().write, Box::new(|_, _| {}));
                let log = log.clone();
                ui.bindings.get_mut(&id).unwrap().write = Box::new(move |value, tx| {
                    log.borrow_mut().push(node);
                    original(value, tx);
                });
                ids.push(id);
            }
            for id in &retired { assert!(matches!(ui.unbind(*id), Err(Error::InvalidBinding))); }
            let result = ui.transaction(|tx| { tx.set(signal, round + 1)?; Ok(()) }).unwrap();
            assert_eq!(result.sink_writes, nodes.len());
            assert_eq!(*log.borrow(), nodes.iter().rev().copied().collect::<Vec<_>>());
            assert_eq!(ui.bindings.slots.len(), nodes.len());
            for &id in ids.iter().step_by(2).chain(ids.iter().skip(1).step_by(2)) { ui.unbind(id).unwrap(); }
            retired.extend(ids);
            assert_eq!(ui.binding_count(), 0);
            assert_eq!(ui.bindings.free.len(), nodes.len());
        }
        ui.dispose_signal(signal).unwrap();
    }
}
